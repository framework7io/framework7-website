import * as React from 'react';

declare namespace F7RoutableModals {
  interface Props {
    slot? : string
    
  }
}
declare class F7RoutableModals extends React.Component<F7RoutableModals.Props, {}> {
  
}
export default F7RoutableModals;
export default {
  name: 'timeline',
};
